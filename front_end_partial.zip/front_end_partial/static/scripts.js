general_var=null;
general=null;
$( document ).ready(function() {
  $('#inputGroupFile').on('change',function(){
      //get the file name
      var fileName = $(this).val();
      var fileNameParts =  fileName.split('\\');
      //replace the "Choose a file" label
      $(this).next('.custom-file-label').html(fileNameParts.pop());
      previewSourceImg(this);


  });
whut=null;
  function previewSourceImg(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();
        reader.onload = function (e) {
          $('#source-img').attr('src', e.target.result);
          general=e.target.result;
         // whut=e.target
        }
        reader.readAsDataURL(input.files[0]);

    }
  }

  $('.btn-primary').click(function(){
      console.log("TEST");
      //general=encodeURL(general)
      //generate_image();

      $('#final_image').attr('src',"static/gif_x.gif");

      //print("WTF");
      //console.log(whut);
  });

 function encodeURL(str){
     return str ;
    //return str.replace(/\+/g, '-').replace(/\//g, '_').replace(/\=+$/, '');
}




});




function generate_image(){


            $.ajax({
                url: "api/generate_image",
                type: "POST",
                data: 'jsonData=' + JSON.stringify({'user_id':general}),
                success: function (response) {
                  console.log('unsure messages Receives'+response);


                }.bind(this)

            });
        }

